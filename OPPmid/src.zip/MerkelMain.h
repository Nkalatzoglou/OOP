#pragma once

#include <vector>
#include "OrderBookEntry.h"
#include "OrderBook.h"
#include "Wallet.h"
#include "Candlestick.h"

class MerkelMain
{
    public:
        MerkelMain();
        /** Call this to start the sim */
        void init();
    private:
        // START OF MY CODE

        int findCandleStick(std::string timeframe, OrderBookType type, std::string product);
        std::vector<Candlestick> calculateCandlesticks(std::string timeframe, std::string prevTimeFrame);
        void plot_data(std::vector<Candlestick> plot_candlesticks);
        void plot_volume(std::string product);

        // END OF MY CODE

        void printMenu();
        void printHelp();
        void printMarketStats();
        void enterAsk();
        void enterBid();
        void printWallet();
        void gotoNextTimeframe();
        int getUserOption(int num_options);
        void processUserOption(int userOption);

        std::string currentTime;

    //    OrderBook orderBook{"20200317.csv"};
    	OrderBook orderBook{"20200601.csv"};
        Wallet wallet;
        
        // START OF MY CODE

        std::vector<Candlestick> candleSticks;

        // END OF MY CODE
};
