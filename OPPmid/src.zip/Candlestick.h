// START OF MY CODE
#include <string>
#include "OrderBookEntry.h"

class Candlestick{
    public:
        // Default constructor 
        Candlestick();
        // Initialization constructor
        Candlestick(std::vector<OrderBookEntry> orders, double _low, double _high, double _open);

        // Getter functions of the members
        std::string getTime();
        std::string getProduct();
        OrderBookType getOrderType();
        double getClose();
        double getLow();
        double getHigh();
        double getOpen();

        // Converts object to ascii representation
        char** toText(double* range);
    private:
        std::string timeframe;
        std::string product;
        OrderBookType orderType;
        double low;
        double high;
        double open;
        double close;
};

// END OF MY CODE