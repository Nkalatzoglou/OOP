// START OF MY CODE

#include <iostream>
#include <vector>
#include "Candlestick.h"
#include "OrderBook.h"
#include "OrderBookEntry.h"

Candlestick::Candlestick(){

}

// Main constructor that initializes all object fields and calculates close price
Candlestick::Candlestick(std::vector<OrderBookEntry> orders, double _low, double _high, double _open): low(_low), high(_high), open(_open){
    timeframe = orders[0].timestamp;
    orderType = orders[0].orderType;
    product = orders[0].product;

    double total_amount = 0;
    double total_value = 0;

    for (const auto& order : orders){
        total_amount = total_amount + order.amount;
        total_value = total_value + (order.price * order.amount);
    }

    close = total_value / total_amount;
}
std::string Candlestick::getTime(){
    return this->timeframe;
}

std::string Candlestick::getProduct(){
    return this->product;
}

OrderBookType Candlestick::getOrderType(){
    return this->orderType;
}

double Candlestick::getClose(){
    return this->close;
}

double Candlestick::getLow(){
    return this->low;
}
double Candlestick::getHigh(){
    return this->high;
}
double Candlestick::getOpen(){
    return this->open;
}


// Candlestick-to-ASCII function
char** Candlestick::toText(double* range){
    char** text_candlestick = new char*[30];
    int low_index, high_index, open_index, close_index;

    // Initializes array
    for(int i=0; i<30; i++){
        text_candlestick[i] = new char[21];
        for(int j=0; j<21; j++){
            text_candlestick[i][j] = ' ';
        }
    }


    // find the correspondence of the candlestick low, high, open, close values with the numeric range of the final plot
    for(int i=1; i<30; i++){
        if(range[i-1] >= this->high && this->high > range[i]){
            if(range[i-1] - this->high < this->high - range[i]){
                high_index = i-1;
            }
            else{
                high_index = i;
            }
        }
        if(range[i-1] >= this->low && this->low > range[i]){
            if(range[i-1] - this->low < this->low - range[i]){
                low_index = i-1;
            }
            else{
                low_index = i;
            }
        }
        if(range[i-1] >= this->open && this->open > range[i]){
            if(range[i-1] - this->open < this->open - range[i]){
                open_index = i-1;
            }
            else{
                open_index = i;
            }
        }
        if(range[i-1] >= this->close && this->close > range[i]){
            if(range[i-1] - this->close < this->close - range[i]){
                close_index = i-1;
            }
            else{
                close_index = i;
            }
        }
    }

    // open > close visualisation case
    if(open > close){
        for(int i=high_index; i<open_index; i++){
            text_candlestick[i][10] = '|';
        }
        for(int i=close_index; i<=low_index; i++){
            text_candlestick[i][10] = '|';
        }
        for(int i=open_index; i<=close_index; i++){
            text_candlestick[i][16] = '|';
            text_candlestick[i][4] = '|';
        }
        for(int i=open_index; i<close_index+1; i++){
            for(int j=5; j<16;  j++){
                text_candlestick[i][j] = 'v';
            }
        }
    }
    // open < close visualisation case
    else{
        for(int i=high_index; i<close_index; i++){
            text_candlestick[i][10] = '|';
        }
        for(int i=open_index; i<=low_index; i++){
            text_candlestick[i][10] = '|';
        }
        for(int i=close_index; i<=open_index; i++){
            text_candlestick[i][16] = '|';
            text_candlestick[i][4] = '|';
        }
        for(int i=close_index; i<open_index+1; i++){
            for(int j=5; j<16;  j++){
                text_candlestick[i][j] = '^';
            }
        } 
    }

    // Time value in X-axis
    int k=11;
    for(int j=7; j<15; j++){
        text_candlestick[29][j] = timeframe[k];
        k++;
    }

    return text_candlestick;
}

// END OF MY CODE